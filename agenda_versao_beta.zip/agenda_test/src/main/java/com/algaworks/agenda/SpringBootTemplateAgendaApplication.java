package com.algaworks.agenda;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringBootTemplateAgendaApplication {

	public static void main(String[] args) {
		SpringApplication.run(SpringBootTemplateAgendaApplication.class, args);
	}
}
